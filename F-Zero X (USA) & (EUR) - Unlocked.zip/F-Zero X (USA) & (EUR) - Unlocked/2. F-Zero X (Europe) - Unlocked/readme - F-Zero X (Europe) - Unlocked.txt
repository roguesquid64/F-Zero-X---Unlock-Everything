F-Zero X - Unlocked
 
This ROM Hack of F-Zero X (EUR), Unlocks All Pilots/Machines, GP Modes, Courses, X Marks, and Adds Additional Features. 

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:
Alternate Title Screen
All 30 Unique Pilots/Machines Available
All GP Modes Available (Novice, Standard, Expert, Master)
All Courses Available (Jack Cup, Queen Cup, King Cup, Joker Cup, X Cup)
X Marks for all GP Modes and Courses (X Cup does not have any unlockable X Marks)
Infinite Retire (Lives) in GP Mode
Additional Color for all racers (Works with Player 1, Player 2, Player 3, and Player 4)

Infinite Retire (Lives) in GP Mode Details:
In GP Mode if you Retry, Destroy your Machine, or Change Settings, it will not be treated as a Retire and cost you a life. 

Additional Color Details:
To enable the additional color, press Z+R on your N64 controller while on the Acceleration-Maxspeed modify screen.


Patching Information: 
Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of F-Zero X ROM with the included corresponding Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/ 


2.
Database match: F-Zero X (Europe)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: AF9038BCB543A2B4FAAAB876DBDAB4663859E092
File/ROM CRC32: 2D6F7E8B